package com.student.ecommerce.model;

/**
 * Student Model - Represents a student/user in the system
 * AI Prompt: "Add fields like phone, address, or profile picture URL to this class"
 */
public class Student {
    private int id;
    private String name;
    private String email;
    private String password;
    private String role; // "student" or "admin"

    public Student() {}

    public Student(String name, String email, String password, String role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    @Override
    public String toString() {
        return "Student{id=" + id + ", name=" + name + ", email=" + email + "}";
    }
}
